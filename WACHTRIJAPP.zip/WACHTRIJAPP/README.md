Let op: een C#-project open je altijd door te dubbelklikken op `.sln`-file. Je kunt hierbij niet werken met File > Open folder.
